// connect.js

// проблема наступного коду в тому, що я при парсингу 
// сторінки для перевірки наявності "коду з серверу"
// не бачу наявного 
// <script src="http://localhost:8080/storage/versatile.js" ></script>
// хоч при відкритті сторінки браузера він є, і він працює, 
// тобто якісь прінти з versatile.js, спокійно виводяться в "зовнішньому"
// проєкті

var scriptTag = document.createElement('script');
scriptTag.src = 'http://localhost:8080/storage/versatile.js';
document.body.appendChild(scriptTag);

